# food-delivery-website

###### A simple food delivery website using HTML, CSS and JavaScript+

See demo: https://fahadchy24.github.io/food-delivery-website/